To load dummy jobs use the following (in the job board directory)
python manage.py loaddata .\dummy_jobs.json

To Run the server use the following (in the job board directory)
python manage.py runserver